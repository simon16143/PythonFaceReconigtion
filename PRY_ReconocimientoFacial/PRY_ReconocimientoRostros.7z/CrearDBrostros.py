#https://docs.opencv.org/3.4/db/d28/tutorial_cascade_classifier.html
#https://opencv.org/
#https://revistadigital.inesem.es/informatica-y-tics/opencv/

#instalar opencv: detección de rostros y objetos
#!pip install opencv-python
#imutils: Una serie de funciones de conveniencia para hacer funciones básicas de procesamiento de imágenes 
#!pip install imutils

import cv2
import os
import imutils

#cambiar por el nombre de la persona que vamos a guardar las imagenes
print("¿Nombre de la persona?")
nombre = input()
personName = nombre
#ruta Data
dataPath = 'Reconocimiento Facial/Data'
personPath = dataPath + '/' + personName

#crear la carpeta si no existe
if not os.path.exists(personPath):
    os.makedirs(personPath)
#captura de imagenes por medio de la camara
cap = cv2.VideoCapture(0,cv2.CAP_DSHOW)
#cap = cv2.VideoCapture('videoCamila.mp4')
faceClassif = cv2.CascadeClassifier(cv2.data.haarcascades+'haarcascade_frontalface_default.xml')
count = 0
#almacenar 300 rostros y luego se cierra
while True:  
    ret, frame = cap.read()
    if ret == False: break
    #redimensionar el tamaño de los fotogramas del video de entrada
    frame =  imutils.resize(frame, width=640)
    gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
    auxFrame = frame.copy()
    faces = faceClassif.detectMultiScale(gray,1.3,5)
    for (x,y,w,h) in faces:
        cv2.rectangle(frame, (x,y),(x+w,y+h),(0,255,0),2)
        rostro = auxFrame[y:y+h,x:x+w]
        rostro = cv2.resize(rostro,(150,150),interpolation=cv2.INTER_CUBIC)
        cv2.imwrite(personPath + '/rotro_{}.jpg'.format(count),rostro)
        count = count + 1
    cv2.imshow('frame',frame)
    k =  cv2.waitKey(1)
    if k == 27 or count >= 300:
        break
cap.release()
cv2.destroyAllWindows()
